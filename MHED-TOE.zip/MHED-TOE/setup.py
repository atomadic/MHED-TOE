"""
MHED-TOE v2.1: The Monadic-Hex Entropic Dynamics Theory of Everything
Setup configuration
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="mhedtoe",
    version="2.1.0",
    author="Thomas Ralph Colvin IV",
    author_email="Atomadic@proton.me",
    description="A Unified Framework for Quantum Gravity, the Standard Model, and Consciousness",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Atomadic/MHED-TOE",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Physics",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.9",
    install_requires=requirements,
    extras_require={
        "dev": [
            "pytest>=6.2.0",
            "pytest-cov>=3.0.0",
            "black>=21.0",
            "flake8>=3.9.0",
            "mypy>=0.910",
        ],
        "gpu": [
            "torch>=1.10.0",
            "cupy>=10.0.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "mhedtoe-derive=derivations.zero_parameters:main",
            "mhedtoe-simulate=simulations.master_equation:main",
            "mhedtoe-predict=predictions.mt_coherence:main",
        ],
    },
    include_package_data=True,
    package_data={
        "": ["data/*.npy", "data/*.json", "data/*.csv"],
    },
)
