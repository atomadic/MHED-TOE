"""
MHED-TOE v2.1: E₈ Root System
==============================

Generates the 248 roots of the E₈ Lie algebra:
- 240 non-zero roots (norm² = 2)
- 8 Cartan subalgebra elements (zero roots)

E₈ construction via D₈ (SO(16)) + 128 spinor weights.
"""

import numpy as np
from itertools import combinations, product

def generate_d8_roots():
    """
    Generate D₈ roots: all vectors with ±1 in exactly two positions.
    
    Returns:
        np.ndarray: Shape (112, 8) - D₈ roots
    """
    roots = []
    
    # Choose 2 positions for ±1
    for i, j in combinations(range(8), 2):
        for sign1, sign2 in product([1, -1], repeat=2):
            root = np.zeros(8)
            root[i] = sign1
            root[j] = sign2
            roots.append(root)
    
    return np.array(roots)


def generate_e8_spinor_weights():
    """
    Generate 128 E₈ spinor weights from D₈.
    
    Half-integer vectors: (±1/2, ±1/2, ..., ±1/2) with even # of -1/2's
    
    Returns:
        np.ndarray: Shape (128, 8) - spinor weights
    """
    weights = []
    
    # Generate all 2^8 = 256 combinations
    for signs in product([0.5, -0.5], repeat=8):
        vector = np.array(signs)
        # Keep only those with even number of negative entries
        if np.sum(vector < 0) % 2 == 0:
            weights.append(vector)
    
    return np.array(weights)


def generate_e8_roots_full():
    """
    Generate complete E₈ root system (240 roots + 8 Cartan).
    
    Returns:
        dict: {
            'roots': np.ndarray shape (240, 8),
            'cartan': np.ndarray shape (8, 8),
            'all': np.ndarray shape (248, 8)
        }
    """
    # D₈ roots (112 vectors)
    d8_roots = generate_d8_roots()
    
    # Spinor weights (128 vectors)
    spinor_weights = generate_e8_spinor_weights()
    
    # Combine for 240 non-zero roots
    roots = np.vstack([d8_roots, spinor_weights])
    
    # Verify count
    assert roots.shape[0] == 240, f"Expected 240 roots, got {roots.shape[0]}"
    
    # Verify all have norm² = 2
    norms_squared = np.sum(roots**2, axis=1)
    assert np.allclose(norms_squared, 2.0), "E₈ roots must have norm² = 2"
    
    # Cartan subalgebra: 8 orthogonal basis vectors
    cartan = np.eye(8)
    
    # All 248 elements
    all_vectors = np.vstack([roots, cartan])
    
    return {
        'roots': roots,
        'cartan': cartan,
        'all': all_vectors,
        'dim': 248,
        'num_roots': 240,
        'num_cartan': 8
    }


def verify_e8_properties(e8_data):
    """
    Verify E₈ mathematical properties.
    
    Args:
        e8_data: Output from generate_e8_roots_full()
    
    Returns:
        dict: Verification results
    """
    roots = e8_data['roots']
    
    checks = {}
    
    # Check 1: Root count
    checks['root_count'] = (roots.shape[0] == 240)
    
    # Check 2: Norm squared = 2
    norms_sq = np.sum(roots**2, axis=1)
    checks['norms'] = np.allclose(norms_sq, 2.0)
    
    # Check 3: Inner products are integers
    # Sample check (full check is expensive: 240×240 = 57,600 pairs)
    sample_size = 100
    indices = np.random.choice(240, size=sample_size, replace=False)
    sample_roots = roots[indices]
    inner_products = sample_roots @ sample_roots.T
    checks['integer_products'] = np.allclose(inner_products, np.round(inner_products))
    
    # Check 4: Allowed inner products: {0, ±1, ±2}
    unique_products = np.unique(np.round(inner_products))
    allowed = {-2, -1, 0, 1, 2}
    checks['allowed_products'] = set(unique_products).issubset(allowed)
    
    # Check 5: Dimension
    checks['dimension'] = (e8_data['dim'] == 248)
    
    return checks


def project_to_triality_sectors(roots):
    """
    Project E₈ roots onto 3 triality sectors via octonion automorphisms.
    
    Args:
        roots: np.ndarray shape (240, 8)
    
    Returns:
        dict: {
            'sector_0': np.ndarray,
            'sector_1': np.ndarray,
            'sector_2': np.ndarray
        }
    """
    # Triality operators (approximate, for demonstration)
    # Full implementation requires octonion multiplication tables
    
    n_roots = roots.shape[0]
    sector_size = n_roots // 3
    
    # Simple partitioning (real triality is more complex)
    sectors = {
        'sector_0': roots[:sector_size],
        'sector_1': roots[sector_size:2*sector_size],
        'sector_2': roots[2*sector_size:]
    }
    
    return sectors


def compute_yukawa_eigenvalues(roots):
    """
    Compute Yukawa coupling eigenvalues from E₈ → MT projection.
    
    This is a placeholder for the full derivation in embedding_matrix.py
    
    Args:
        roots: E₈ roots
    
    Returns:
        dict: Particle masses
    """
    # Simplified: Use root norms and angles
    # Full calculation requires M matrix from embedding_matrix.py
    
    # Placeholder values (actual derivation is complex)
    masses = {
        'higgs': 124.8,  # GeV
        'top': 172.9,
        'bottom': 4.18,
        'charm': 1.27,
        'strange': 0.095,
        'up': 0.0023,  # 2.3 MeV
        'down': 0.0048,  # 4.8 MeV
    }
    
    return masses


def save_e8_data(filepath='data/e8_roots.npy'):
    """
    Generate and save E₈ data to file.
    
    Args:
        filepath: Output path
    """
    import os
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    
    e8_data = generate_e8_roots_full()
    np.save(filepath, e8_data['all'])
    
    print(f"E₈ data saved to {filepath}")
    print(f"  Shape: {e8_data['all'].shape}")
    print(f"  240 roots + 8 Cartan = 248 total")
    
    return filepath


def main():
    """Command-line interface."""
    import argparse
    
    parser = argparse.ArgumentParser(description="Generate E₈ root system")
    parser.add_argument('--verify', action='store_true', help='Run verification')
    parser.add_argument('--save', type=str, default='data/e8_roots.npy',
                       help='Save to file')
    
    args = parser.parse_args()
    
    print("=" * 70)
    print("MHED-TOE v2.1: E₈ Root System Generation")
    print("=" * 70)
    print()
    
    # Generate E₈
    e8_data = generate_e8_roots_full()
    print(f"Generated {e8_data['num_roots']} roots + {e8_data['num_cartan']} Cartan")
    print(f"Total dimension: {e8_data['dim']}")
    print()
    
    # Verify
    if args.verify:
        print("Running verification checks...")
        checks = verify_e8_properties(e8_data)
        for name, passed in checks.items():
            status = "✓" if passed else "✗"
            print(f"  {name}: {status}")
        print()
    
    # Save
    if args.save:
        save_e8_data(args.save)
    
    print("=" * 70)
    
    return e8_data


if __name__ == '__main__':
    main()
