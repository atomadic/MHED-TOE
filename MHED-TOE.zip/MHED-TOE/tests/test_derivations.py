"""
MHED-TOE v2.1: Unit Tests for Zero-Parameter Derivations
=========================================================

Tests that all fundamental constants are correctly derived.
"""

import pytest
import numpy as np
from sympy import sqrt, simplify, N as numerical_eval

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from derivations import zero_parameters


class TestZeroParameters:
    """Test suite for zero-parameter derivations."""
    
    def test_lambda_derivation(self):
        """Test λ = 60/217 derivation."""
        result = zero_parameters.derive_lambda()
        
        # Check exact value
        assert result['exact'] == 60/217 or result['verification'], \
            "Lambda should equal 60/217"
        
        # Check numerical value
        expected = 60 / 217
        assert np.abs(result['numerical'] - expected) < 1e-10, \
            f"Lambda numerical value incorrect: {result['numerical']} vs {expected}"
    
    def test_eta_retro_derivation(self):
        """Test η_retro = 91(3+√5)/(992√2) derivation."""
        result = zero_parameters.derive_eta_retro()
        
        # Check target value
        target = 91 * (3 + np.sqrt(5)) / (992 * np.sqrt(2))
        assert np.abs(result['numerical'] - target) < 1e-6, \
            f"Eta_retro incorrect: {result['numerical']} vs {target}"
        
        # Check range
        assert 0.08 < result['numerical'] < 0.09, \
            "Eta_retro should be ~0.0848"
    
    def test_beta_derivation(self):
        """Test β = 24(3+√5)/5425 derivation."""
        result = zero_parameters.derive_beta()
        
        # Check target value
        target = 24 * (3 + np.sqrt(5)) / 5425
        assert np.abs(result['numerical'] - target) < 1e-6, \
            f"Beta incorrect: {result['numerical']} vs {target}"
        
        # Check range
        assert 0.02 < result['numerical'] < 0.03, \
            "Beta should be ~0.0232"
    
    def test_gamma_MD_derivation(self):
        """Test γ_MD = 1/2 derivation."""
        result = zero_parameters.derive_gamma_MD()
        
        assert result['exact'] == 0.5, "Gamma_MD should equal exactly 0.5"
        assert result['numerical'] == 0.5, "Gamma_MD numerical should be 0.5"
    
    def test_Lambda_derivation(self):
        """Test Λ = 12Φ⁴⁵/N_monad derivation."""
        result = zero_parameters.derive_Lambda()
        
        # Check order of magnitude
        assert 1e-124 < result['numerical'] < 1e-122, \
            "Lambda should be ~10^-123"
        
        # Check agreement with observation
        assert result['agreement'], \
            "Lambda should agree with Planck 2018 within 5%"
        
        # Check deviation
        assert result['deviation_percent'] < 10, \
            f"Lambda deviation too large: {result['deviation_percent']}%"
    
    def test_all_constants_positive(self):
        """Test that all constants are positive."""
        results = zero_parameters.compute_all()
        
        for name, data in results.items():
            assert data['numerical'] > 0, \
                f"{name} should be positive, got {data['numerical']}"
    
    def test_constants_reproducibility(self):
        """Test that derivations are reproducible."""
        results1 = zero_parameters.compute_all()
        results2 = zero_parameters.compute_all()
        
        for name in results1.keys():
            val1 = results1[name]['numerical']
            val2 = results2[name]['numerical']
            assert np.abs(val1 - val2) < 1e-15, \
                f"{name} not reproducible: {val1} vs {val2}"
    
    def test_golden_ratio_consistency(self):
        """Test that golden ratio Φ is used consistently."""
        PHI_expected = (1 + np.sqrt(5)) / 2
        
        # Check in beta derivation
        beta_result = zero_parameters.derive_beta()
        # PHI should appear in components
        assert 'fibonacci' in beta_result['components'], \
            "Beta should use golden ratio"
    
    def test_e8_dimension_consistency(self):
        """Test that E₈ dimension (248) is used consistently."""
        # Check lambda uses dim(E₈) = 248
        lambda_result = zero_parameters.derive_lambda()
        assert '248' in lambda_result['formula'], \
            "Lambda should reference E₈ dimension 248"
        
        # Check eta_retro uses dim(E₈) = 248
        eta_result = zero_parameters.derive_eta_retro()
        # The formula should involve 248 somehow
        # (This is implicit in the normalization factor)


class TestPhysicalConsistency:
    """Test physical consistency of derived constants."""
    
    def test_lambda_range(self):
        """Test λ is in physically reasonable range for coupling."""
        result = zero_parameters.derive_lambda()
        # Coupling constants typically 0 < λ < 1
        assert 0 < result['numerical'] < 1, \
            "Lambda should be between 0 and 1"
    
    def test_beta_soliton_stability(self):
        """Test β is in range for stable solitons."""
        result = zero_parameters.derive_beta()
        # For stable bright solitons, β > 0
        # For microtubules, expect β ~ 0.01-0.1
        assert 0.001 < result['numerical'] < 0.1, \
            "Beta should be in soliton stability range"
    
    def test_gamma_dissipation_rate(self):
        """Test γ_MD is positive (required for dissipation)."""
        result = zero_parameters.derive_gamma_MD()
        assert result['numerical'] > 0, \
            "Dissipation rate must be positive"
    
    def test_cosmological_constant_order(self):
        """Test Λ is in correct cosmological order."""
        result = zero_parameters.derive_Lambda()
        # Observed Λ ~ 10^-123 in Planck units
        log10_Lambda = np.log10(result['numerical'])
        assert -125 < log10_Lambda < -120, \
            f"Cosmological constant wrong order: 10^{log10_Lambda}"


class TestMathematicalProperties:
    """Test mathematical properties of derivations."""
    
    def test_exact_fractions(self):
        """Test that exact values are proper fractions."""
        # Lambda should be 60/217 (irreducible)
        lambda_result = zero_parameters.derive_lambda()
        assert lambda_result['value'] == 60/217
        
        # Check GCD(60, 217) = 1 (irreducible)
        from math import gcd
        assert gcd(60, 217) == 1, "60/217 should be irreducible"
    
    def test_algebraic_numbers(self):
        """Test that constants involving √5 are handled correctly."""
        eta_result = zero_parameters.derive_eta_retro()
        beta_result = zero_parameters.derive_beta()
        
        # Both should involve (3 + √5) term
        # Numerical check: should be irrational
        assert not np.isclose(eta_result['numerical'], 
                            round(eta_result['numerical'], 10)), \
            "Eta_retro should be irrational (involves √5)"


def test_compute_all_integration():
    """Integration test: compute all constants together."""
    results = zero_parameters.compute_all()
    
    # Check all keys present
    expected_keys = ['lambda', 'eta_retro', 'beta', 'gamma_MD', 'Lambda']
    for key in expected_keys:
        assert key in results, f"Missing key: {key}"
    
    # Check all have required fields
    for name, data in results.items():
        assert 'numerical' in data, f"{name} missing numerical value"
        assert 'formula' in data, f"{name} missing formula"


if __name__ == '__main__':
    # Run tests with pytest
    pytest.main([__file__, '-v'])
