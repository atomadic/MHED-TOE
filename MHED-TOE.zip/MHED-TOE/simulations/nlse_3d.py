"""
MHED-TOE v2.1: 3D Nonlinear Schrödinger Equation Solver
========================================================

Solves the 3D NLSE for microtubule solitons:
    iℏ ∂ψ/∂t = -ℏ²/(2m) ∇²ψ + V(r)ψ + β|ψ|²ψ

Uses split-step Fourier method for efficient evolution.
"""

import numpy as np
from scipy.fft import fftn, ifftn, fftfreq
import matplotlib.pyplot as plt
from tqdm import tqdm


class NLSE3DSolver:
    """
    3D Nonlinear Schrödinger Equation solver for microtubules.
    """
    
    def __init__(self, grid_size=(64, 32, 128), domain_size=(25, 25, 100),
                 beta=0.023164, mass=1.0, hbar=1.0):
        """
        Initialize solver.
        
        Args:
            grid_size: (nx, ny, nz) grid points
            domain_size: (Lx, Ly, Lz) in nm
            beta: Nonlinear coefficient (dimensionless)
            mass: Effective tubulin mass (natural units)
            hbar: Reduced Planck constant (natural units)
        """
        self.nx, self.ny, self.nz = grid_size
        self.Lx, self.Ly, self.Lz = domain_size
        self.beta = beta
        self.m = mass
        self.hbar = hbar
        
        # Spatial grids
        self.x = np.linspace(-self.Lx/2, self.Lx/2, self.nx)
        self.y = np.linspace(-self.Ly/2, self.Ly/2, self.ny)
        self.z = np.linspace(-self.Lz/2, self.Lz/2, self.nz)
        self.X, self.Y, self.Z = np.meshgrid(self.x, self.y, self.z, indexing='ij')
        
        # Momentum space grids
        self.kx = 2 * np.pi * fftfreq(self.nx, d=self.Lx/self.nx)
        self.ky = 2 * np.pi * fftfreq(self.ny, d=self.Ly/self.ny)
        self.kz = 2 * np.pi * fftfreq(self.nz, d=self.Lz/self.nz)
        self.KX, self.KY, self.KZ = np.meshgrid(self.kx, self.ky, self.kz, indexing='ij')
        self.K2 = self.KX**2 + self.KY**2 + self.KZ**2
        
        # Kinetic energy operator in momentum space
        self.K_hat = -self.hbar**2 * self.K2 / (2 * self.m)
    
    def potential_cylinder(self, radius=12.5):
        """
        Cylindrical potential for microtubule.
        
        Args:
            radius: MT radius in nm
        
        Returns:
            np.ndarray: Potential V(r)
        """
        R = np.sqrt(self.X**2 + self.Y**2)
        V = np.where(R < radius, 0.0, 100.0)  # Infinite well approximation
        return V
    
    def initial_soliton(self, amplitude=1.0, width=5.0, k0=0.0):
        """
        Initial soliton wavefunction: bright soliton.
        
        Args:
            amplitude: Peak amplitude
            width: Spatial width (nm)
            k0: Initial momentum
        
        Returns:
            np.ndarray: ψ(r, t=0)
        """
        psi = amplitude * np.exp(-0.5 * (self.Z / width)**2)
        psi *= np.exp(1j * k0 * self.Z)
        
        # Normalize
        norm = np.sqrt(np.sum(np.abs(psi)**2))
        psi /= norm
        
        return psi
    
    def evolve_split_step(self, psi0, dt=0.2, n_steps=1000, V=None):
        """
        Evolve using split-step Fourier method.
        
        Args:
            psi0: Initial wavefunction
            dt: Time step (fs)
            n_steps: Number of steps
            V: External potential (optional)
        
        Returns:
            dict: {
                'psi': final wavefunction,
                'psi_history': array of wavefunctions,
                'energy_history': array of energies,
                'times': time array
            }
        """
        psi = psi0.copy()
        
        if V is None:
            V = self.potential_cylinder()
        
        # Store history
        psi_history = []
        energy_history = []
        times = np.arange(n_steps) * dt
        
        # Precompute propagators
        U_K = np.exp(-1j * self.K_hat * dt / self.hbar)
        
        for step in tqdm(range(n_steps), desc="Evolving NLSE"):
            # Half-step nonlinear
            psi *= np.exp(-1j * (V + self.beta * np.abs(psi)**2) * dt / (2 * self.hbar))
            
            # Full-step kinetic (in Fourier space)
            psi_k = fftn(psi)
            psi_k *= U_K
            psi = ifftn(psi_k)
            
            # Half-step nonlinear
            psi *= np.exp(-1j * (V + self.beta * np.abs(psi)**2) * dt / (2 * self.hbar))
            
            # Compute energy
            if step % 10 == 0:  # Sample every 10 steps
                E = self.compute_energy(psi, V)
                energy_history.append(E)
                psi_history.append(psi.copy())
        
        return {
            'psi': psi,
            'psi_history': np.array(psi_history),
            'energy_history': np.array(energy_history),
            'times': times[::10]  # Match sampling
        }
    
    def compute_energy(self, psi, V):
        """
        Compute total energy: E = E_kin + E_pot + E_nonlinear.
        
        Args:
            psi: Wavefunction
            V: Potential
        
        Returns:
            float: Total energy
        """
        # Kinetic energy (in momentum space)
        psi_k = fftn(psi)
        E_kin = np.sum(self.K_hat * np.abs(psi_k)**2).real
        
        # Potential energy
        E_pot = np.sum(V * np.abs(psi)**2).real
        
        # Nonlinear energy
        E_nonlinear = self.beta * np.sum(np.abs(psi)**4).real / 2
        
        return E_kin + E_pot + E_nonlinear
    
    def compute_coherence_time(self, psi_history):
        """
        Estimate coherence time from purity decay.
        
        Args:
            psi_history: Array of wavefunctions over time
        
        Returns:
            float: Coherence time (fs)
        """
        # Compute purity Tr(ρ²) over time
        purity = []
        for psi in psi_history:
            rho = np.outer(psi.flatten(), psi.flatten().conj())
            P = np.trace(rho @ rho).real
            purity.append(P)
        
        purity = np.array(purity)
        
        # Find when purity drops to 1/e
        threshold = purity[0] / np.e
        idx = np.where(purity < threshold)[0]
        
        if len(idx) > 0:
            tau_coh = idx[0] * 10 * 0.2  # steps * sampling * dt
        else:
            tau_coh = np.inf
        
        return tau_coh
    
    def plot_results(self, results, save_path=None):
        """
        Visualize simulation results.
        
        Args:
            results: Output from evolve_split_step()
            save_path: Optional save path for figure
        """
        fig, axes = plt.subplots(2, 2, figsize=(12, 10))
        
        # Initial vs final wavefunction (z-slice at center)
        psi0 = results['psi_history'][0]
        psi_final = results['psi']
        
        nx_mid = self.nx // 2
        ny_mid = self.ny // 2
        
        # Plot |ψ|² along z-axis
        ax = axes[0, 0]
        ax.plot(self.z, np.abs(psi0[nx_mid, ny_mid, :])**2, label='t=0')
        ax.plot(self.z, np.abs(psi_final[nx_mid, ny_mid, :])**2, label='t=final')
        ax.set_xlabel('z (nm)')
        ax.set_ylabel('|ψ|²')
        ax.set_title('Soliton Evolution')
        ax.legend()
        ax.grid(True)
        
        # Energy conservation
        ax = axes[0, 1]
        ax.plot(results['times'], results['energy_history'])
        ax.set_xlabel('Time (fs)')
        ax.set_ylabel('Total Energy')
        ax.set_title('Energy Conservation')
        ax.grid(True)
        
        # 2D cross-section |ψ|²
        ax = axes[1, 0]
        nz_mid = self.nz // 2
        im = ax.imshow(np.abs(psi_final[:, :, nz_mid])**2, 
                      extent=[-self.Lx/2, self.Lx/2, -self.Ly/2, self.Ly/2],
                      origin='lower', cmap='viridis')
        ax.set_xlabel('x (nm)')
        ax.set_ylabel('y (nm)')
        ax.set_title('|ψ|² Cross-Section')
        plt.colorbar(im, ax=ax)
        
        # Phase
        ax = axes[1, 1]
        phase = np.angle(psi_final[nx_mid, ny_mid, :])
        ax.plot(self.z, phase)
        ax.set_xlabel('z (nm)')
        ax.set_ylabel('Phase (rad)')
        ax.set_title('Soliton Phase')
        ax.grid(True)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            print(f"Figure saved to {save_path}")
        
        plt.show()


def evolve(initial_state='soliton', beta=0.023164, timesteps=1000, 
           grid_size=(64, 32, 128), plot=True):
    """
    High-level interface for NLSE evolution.
    
    Args:
        initial_state: 'soliton' or 'gaussian'
        beta: Nonlinear coefficient
        timesteps: Number of time steps
        grid_size: Spatial grid dimensions
        plot: Whether to plot results
    
    Returns:
        dict: Simulation results
    """
    # Initialize solver
    solver = NLSE3DSolver(grid_size=grid_size, beta=beta)
    
    # Initial state
    if initial_state == 'soliton':
        psi0 = solver.initial_soliton(amplitude=1.0, width=5.0)
    else:
        psi0 = solver.initial_soliton(amplitude=1.0, width=10.0)
    
    # Evolve
    print(f"Evolving 3D NLSE with β = {beta:.6f}")
    results = solver.evolve_split_step(psi0, dt=0.2, n_steps=timesteps)
    
    # Coherence time
    tau_coh = solver.compute_coherence_time(results['psi_history'])
    print(f"Estimated coherence time: {tau_coh:.1f} fs")
    
    results['tau_coherence'] = tau_coh
    results['solver'] = solver
    
    # Plot
    if plot:
        solver.plot_results(results)
    
    return results


def main():
    """Command-line interface."""
    import argparse
    
    parser = argparse.ArgumentParser(description="3D NLSE solver for microtubules")
    parser.add_argument('--beta', type=float, default=0.023164,
                       help='Nonlinear coefficient')
    parser.add_argument('--steps', type=int, default=1000,
                       help='Number of time steps')
    parser.add_argument('--no-plot', action='store_true',
                       help='Disable plotting')
    
    args = parser.parse_args()
    
    results = evolve(
        beta=args.beta,
        timesteps=args.steps,
        plot=not args.no_plot
    )
    
    return results


if __name__ == '__main__':
    main()
