# Contributing to MHED-TOE

Thank you for your interest in contributing to the Monadic-Hex Entropic Dynamics Theory of Everything! This project aims to unify quantum gravity, particle physics, and consciousness through rigorous mathematics and testable predictions.

## How to Contribute

### Areas We Need Help With

1. **Experimental Validation**
   - Cryo-EM protocols for detecting 19.47° helical defects
   - Microtubule coherence measurements at physiological temperature
   - LHC data analysis for 0.83 TeV singlet searches
   - Anesthetic dose-response experiments

2. **Numerical Improvements**
   - GPU acceleration for 3D NLSE solver
   - Parallel Monte Carlo for causal-set simulations
   - Higher-order time integration schemes
   - Memory optimization for large-scale runs

3. **Theoretical Extensions**
   - Cosmological implications (inflation, dark energy dynamics)
   - Quantum information theoretic formulation
   - Connection to other TOE candidates
   - Neuroscience applications

4. **Code Quality**
   - Bug fixes and edge case handling
   - Documentation improvements
   - Additional unit tests
   - Performance profiling and optimization

### Getting Started

1. **Fork the repository**
   ```bash
   git clone https://github.com/[YOUR-USERNAME]/MHED-TOE.git
   cd MHED-TOE
   ```

2. **Set up development environment**
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   pip install -e ".[dev]"
   ```

3. **Create a feature branch**
   ```bash
   git checkout -b feature/your-feature-name
   ```

4. **Make your changes**
   - Follow PEP 8 style guidelines
   - Add docstrings to all functions
   - Include type hints where appropriate
   - Write unit tests for new functionality

5. **Run tests**
   ```bash
   pytest tests/ -v
   ```

6. **Submit a pull request**
   - Describe your changes clearly
   - Reference any related issues
   - Ensure all tests pass

## Code Style

### Python
- Follow PEP 8
- Use type hints: `def func(x: float) -> float:`
- Docstrings in NumPy style:
  ```python
  def my_function(arg1: float, arg2: int) -> dict:
      """
      Brief description.
      
      Longer description if needed.
      
      Args:
          arg1: Description of arg1
          arg2: Description of arg2
      
      Returns:
          dict: Description of return value
      
      Raises:
          ValueError: When something goes wrong
      """
      pass
  ```

### Documentation
- Use Markdown for README, docs
- LaTeX for mathematical equations: `$\lambda = 60/217$`
- Include references to papers: `[Author et al., 2023]`

### Commit Messages
- Use present tense: "Add feature" not "Added feature"
- Be descriptive but concise
- Reference issues: "Fix #123: Resolve NLSE boundary condition bug"

## Testing

### Writing Tests
- Place tests in `tests/` directory
- Name test files `test_*.py`
- Name test functions `test_*`
- Use pytest fixtures for setup/teardown
- Aim for >80% code coverage

Example:
```python
import pytest
from derivations import zero_parameters

def test_lambda_derivation():
    """Test that λ = 60/217."""
    result = zero_parameters.derive_lambda()
    assert result['value'] == 60/217
    assert result['verification'] is True
```

### Running Tests
```bash
# All tests
pytest tests/

# Specific file
pytest tests/test_derivations.py -v

# With coverage
pytest --cov=. tests/
```

## Pull Request Process

1. **Before submitting:**
   - Ensure all tests pass
   - Update documentation if needed
   - Add entry to CHANGELOG.md (if applicable)
   - Rebase on latest `main` branch

2. **PR Description should include:**
   - Summary of changes
   - Motivation (why is this change needed?)
   - Testing performed
   - Screenshots (if UI changes)
   - Breaking changes (if any)

3. **Review process:**
   - Maintainers will review within 1 week
   - Address feedback promptly
   - Once approved, PR will be merged

## Reporting Bugs

### Before reporting:
- Check existing issues
- Verify it's reproducible
- Collect relevant information

### Bug report should include:
- Clear title
- Steps to reproduce
- Expected vs. actual behavior
- Environment (OS, Python version, package versions)
- Error messages / stack traces
- Minimal code example

Use this template:
```markdown
## Bug Description
Brief description of the bug.

## Steps to Reproduce
1. Step 1
2. Step 2
3. ...

## Expected Behavior
What should happen.

## Actual Behavior
What actually happens.

## Environment
- OS: [e.g., Ubuntu 22.04]
- Python: [e.g., 3.9.12]
- MHED-TOE version: [e.g., 2.1.0]

## Additional Context
Any other relevant information.
```

## Suggesting Enhancements

We welcome feature requests! Please include:
- Clear description of the enhancement
- Use cases / motivation
- Proposed implementation (if you have ideas)
- Any relevant references / papers

## Code of Conduct

### Our Standards
- Be respectful and inclusive
- Welcome diverse perspectives
- Give and accept constructive feedback
- Focus on what's best for the project and community
- Show empathy towards others

### Unacceptable Behavior
- Harassment or discriminatory language
- Trolling or inflammatory comments
- Personal or political attacks
- Publishing others' private information
- Other conduct inappropriate in a professional setting

### Enforcement
- Violations will be addressed promptly
- Maintainers have the right to remove comments, commits, issues, and other contributions
- Serious violations may result in temporary or permanent ban

## Recognition

Contributors will be:
- Listed in CONTRIBUTORS.md
- Acknowledged in paper acknowledgments (for significant contributions)
- Co-authors on relevant publications (for major theoretical/experimental contributions)

## Questions?

- Open an issue with the `question` label
- Email: Atomadic@proton.me
- Discussion forum: [GitHub Discussions](https://github.com/Atomadic/MHED-TOE/discussions)

## License

By contributing, you agree that your contributions will be licensed under the MIT License.

---

**Thank you for helping advance the Theory of Everything!** 🚀

Your contributions—whether fixing a typo, improving documentation, or adding new features—help push the boundaries of physics, biology, and consciousness studies.

*"The universe is hexagonal, consciousness is fundamental, and together we can prove it."*
